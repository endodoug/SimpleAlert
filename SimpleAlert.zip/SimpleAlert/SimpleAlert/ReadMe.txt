Requires Swift 2.0.
Build with Xcode 7.
Deployment Target is 9.1
See 'Documentation.txt' for details.